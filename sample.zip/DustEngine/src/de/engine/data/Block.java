package de.engine.data;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Block {
	
	/*
	 *  The Block class is essentially a struct equivalent of C/C++ which makes up the Battle Scene.
	 *  
	 *  Contains:
	 *  - Terrain sprite
	 *  - Collision data
	 */
	private static final int WIDTH = 1024, HEIGHT = 664;
	
	private static final int SIZE = 64;
	private int x, y; 								// Actual position of the tiles
	private static int x_mx, y_mx; 					// x_mx = (WIDTH/64 - field_x) * SIZE;
								   					// y_mx = ((HEIGHT-24)/64) - field_y) * SIZE;
	private static int x_offset = 0, y_offset = 0; 	// The actual values that will be added to x,y
	
	private BufferedImage terrain; 					// Terrain is set as private, since USUALLY terrain does not change.
	
	public Block(BufferedImage terrain, int x, int y, int field_x, int field_y) {
		this.terrain = terrain;
		this.x = x;
		this.y = y;
		x_mx = (WIDTH/SIZE - field_x) * SIZE; 		// The values are NEGATIVE, since the effect we are going for
													// is indeed actual opposite of what you can see visually.
		y_mx = (((HEIGHT-24)/SIZE) - field_y) * SIZE;
	}

	public BufferedImage getTerrain() {
		return terrain;
	}

	public void setTerrain(BufferedImage terrain) {
		this.terrain = terrain;
	}
	
	public void update(boolean[] camera_buffer, boolean count) {
		// Pseudo Camera
		
		/*
		 * I give the title Pseudo Camera to this functions below since I'm not
		 * actually moving the 'camera', there isn't any camera, but I'm moving the
		 * tiles themselves to give same effect of camera movement.
		 * 
		 * Therefore, 'Up' is actually tiles moving DOWN, and 'Left' is tiles moving to the RIGHT
		 * and vice versa.
		 */
		if(camera_buffer[0]) { // Up
			if(y_offset < 0 && count) {
				y_offset++;
			}
		}
		if(camera_buffer[1]) { // Left
			if(x_offset < 0 && count) {
				x_offset++;
			}
		}
		if(camera_buffer[2]) { // Down
			if(y_offset > y_mx && count) {
				y_offset--;
			}
		}
		if(camera_buffer[3]) { // Right
			if(x_offset > x_mx && count) {
				x_offset--;
			}
		}
	}
	
	public void render(Graphics g) {
		g.drawImage(terrain, x * SIZE + x_offset, y * SIZE + y_offset, SIZE, SIZE, null);
	}
	
	public int getX_Offset() {
		return x_offset;
	}
	
	public int getY_Offset() {
		return y_offset;
	}
}
