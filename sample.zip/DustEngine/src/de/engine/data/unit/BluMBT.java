package de.engine.data.unit;

import java.awt.Graphics;

import de.engine.data.Actor;
import de.engine.data.Block;
import de.engine.gfx.SpriteSheet;

public class BluMBT extends Actor{

	public BluMBT(SpriteSheet ss, boolean pc, Block[][] field, int x, int y) {
		super(ss, pc, field, x ,y);
		
		image = ss.crop(0, 0);
	}

	public void update() {

	}

	public void render(Graphics g) {
		switch(alignment) {
			case 0:
				
				break;
			case 1:
				
				break;
			case 2:
				
				break;
			case 3:
				
				break;
		}
		
		g.drawImage(image, x * SIZE + field[x][y].getX_Offset(), y * SIZE + field[x][y].getY_Offset(), SIZE, SIZE, null);
	}

}
