package de.engine.data;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Arrays;

import de.engine.Platform;

public class Camera implements KeyListener{

	public void keyPressed(KeyEvent e) {
		boolean temp[] = new boolean[]{false, false, false, false};
		
		switch(e.getKeyCode()) {
			case KeyEvent.VK_W:
				Arrays.fill(temp, false);
				temp[0] = true;
				Platform.getBuffer().setCamera_buffer(temp);
				break;
			case KeyEvent.VK_A:
				Arrays.fill(temp, false);
				temp[1] = true;
				Platform.getBuffer().setCamera_buffer(temp);
				break;
			case KeyEvent.VK_S:
				Arrays.fill(temp, false);
				temp[2] = true;
				Platform.getBuffer().setCamera_buffer(temp);
				break;
			case KeyEvent.VK_D:
				Arrays.fill(temp, false);
				temp[3] = true;
				Platform.getBuffer().setCamera_buffer(temp);
				break;
		}
	}

	public void keyReleased(KeyEvent e) {
		boolean temp[] = new boolean[]{false, false, false, false};
		
		switch(e.getKeyCode()) {
			case KeyEvent.VK_W:
				Platform.getBuffer().setCamera_buffer(temp);
				break;
			case KeyEvent.VK_A:
				Platform.getBuffer().setCamera_buffer(temp);
				break;
			case KeyEvent.VK_S:
				Platform.getBuffer().setCamera_buffer(temp);
				break;
			case KeyEvent.VK_D:
				Platform.getBuffer().setCamera_buffer(temp);
				break;
		}
	}

	public void keyTyped(KeyEvent e) {} // This doesn't do anything

}
