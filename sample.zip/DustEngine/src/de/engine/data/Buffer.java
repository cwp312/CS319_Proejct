package de.engine.data;

public class Buffer {
	// The comprehensive data manager for interaction between instantiated objects
	private boolean camera_buffer[] = new boolean[4];

	public boolean[] getCamera_buffer() {
		return camera_buffer;
	}

	public void setCamera_buffer(boolean camera_buffer[]) {
		this.camera_buffer = camera_buffer;
	}

}
