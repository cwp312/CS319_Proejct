package de.engine.data;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import de.engine.gfx.SpriteSheet;

public abstract class Actor {
	// TODO finish conceptualizing actual implementation
	
	/*
	 * The objects which make up majority of interaction that happens on the Battle Scene.
	 * 
	 * There are few types of Actors in this game:
	 * 1.) Player Controlled
	 * 2.) Enemy
	 * 3.) <Optional> Allied but NPC
	 */
	
	protected final int SIZE = 64;
	
	protected SpriteSheet ss; // Graphics of this unit
	protected BufferedImage image;
	
	protected boolean pc; // Player Controlled or not?
	protected int x, y;
	protected int alignment = 0; // 0 - up / 1 - left / 2 - down / 3 - right
	protected Block field[][];
	
	public Actor(SpriteSheet ss, boolean pc, Block[][] field, int x, int y) {
		this.ss = ss;
		this.pc = pc;
		this.field = field;
		this.x = x;
		this.y = y;
	}
	
	public Actor(SpriteSheet ss, Block field[][], int x, int y) {
		this.ss = ss;
		pc = false;
		this.field = field;
	}
	
	public abstract void render(Graphics g);
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
	public void setY(int y) {
		this.y = y;
	}
}
