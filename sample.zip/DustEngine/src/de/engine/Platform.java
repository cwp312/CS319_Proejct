package de.engine;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.util.ArrayList;

import javax.swing.JFrame;

import de.engine.data.Buffer;
import de.engine.data.Camera;
import de.engine.gfx.BattleScene;
import de.engine.gfx.ImageLoader;
import de.engine.gfx.SpriteSheet;

public class Platform extends Canvas implements Runnable{
	
	private static final long serialVersionUID = 3775130307297116262L;
	
	private static final int WIDTH = 1024, HEIGHT = 664; // The actual game screen size is 640, but
														 // the dimensions actually include the title bar
														 // into the account as well. (Which is 24 pixels)
	private JFrame window = new JFrame("Engine v0.0.1");
	
	private Thread gameThread;
	private boolean running = false;
	
	private ArrayList<SpriteSheet> ss = new ArrayList<SpriteSheet>();
	/*
	 * SpriteSheet types in indexes
	 * 0 - terrain1.png
	 * 1 - actor1.png
	 */
	private ImageLoader il = new ImageLoader();
	
	private BattleScene scn;
	private static Buffer buffer = new Buffer();
	
	public void init() {
		this.addKeyListener(new Camera());
		ss.add(new SpriteSheet(il.load("terrain1")));
		ss.add(new SpriteSheet(il.load("actor1")));
		scn = new BattleScene(ss.get(0), 42, 24);
	}

	public void run() {
		init();
		
		long last = System.nanoTime();
		final double UPS = 60D;
		double ns = 1000000000 / UPS;
		double delta = 0;
		
		while(running) {
			long now = System.nanoTime();

			delta += (now - last) / ns;
			last = now;

			if (delta >= 1) {
				GUAR();
				delta--;
			}
		}
	}
	
	public void GUAR() {
		// Update part
		BattleScene.update(buffer.getCamera_buffer());
				
		// Rendering Part
		BufferStrategy bs = this.getBufferStrategy();
		if(bs == null) {
			createBufferStrategy(3);
			return;
		}
		Graphics g = bs.getDrawGraphics();
		g.fillRect(0, 0, WIDTH, HEIGHT);
		scn.render(g);
		bs.show();
		g.dispose();
	}
	
	public synchronized void start() {
		running = true;
		gameThread = new Thread(this);
		gameThread.start();
	}
	
	public synchronized void stop() {
		running = false;
		try {
			gameThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String args[]) {
		Platform engine = new Platform();
		engine.window.setSize(new Dimension(WIDTH, HEIGHT));
		engine.window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		engine.window.setVisible(true);
		engine.window.setResizable(false);
		engine.window.add(engine);
		
		engine.start();
	}
	
	public static Buffer getBuffer() {
		return buffer;
	}
}
