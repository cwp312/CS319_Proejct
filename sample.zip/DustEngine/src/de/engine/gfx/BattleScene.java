package de.engine.gfx;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.Random;

import de.engine.data.Block;

public class BattleScene {
//	private TileSetter set;
	
	private static int field_x, field_y;
	private static Block field[][];
	private SpriteSheet ss;
	
	private final static int SENSITIVITY = 179;
	
	private static int count_up = 0, count_down = 0, count_left = 0, count_right = 0;
	
	public BattleScene(SpriteSheet ss, int field_x, int field_y) {
		this.ss = ss;
		BattleScene.field_x = field_x;
		BattleScene.field_y = field_y;
		field = new Block[field_x][field_y];
		
		randomGenScene();
	}
	
	private void randomGenScene() {
		Random rand = new Random();
		BufferedImage terrain;
		
		for(int h = 0; h < field_y; h++) {
			for(int w = 0; w < field_x; w++) {
				switch(rand.nextInt(3)) {
					case 0:
						terrain = ss.crop(0, 0);
						break;
					case 1:
						terrain = ss.crop(1, 0);
						break;
					case 2:
						terrain = ss.crop(2, 0);
						break;
					default:
						terrain = ss.crop(0, 0);
						break;
				}
				
				field[w][h] = new Block(terrain, w, h, field_x, field_y);
			}
		}
	}
	
	public static void update(boolean camera_buffer[]) {
		for(int h = 0; h < field_y; h++) {
			for(int w = 0; w < field_x; w++) {
				field[w][h].update(camera_buffer, count(camera_buffer));
			}
		}
	}
	
	public void render(Graphics g) {
		for(int h = 0; h < field_y; h++) {
			for(int w = 0; w < field_x; w++) {
				field[w][h].render(g);
			}
		}
	}
	
	public static boolean count(boolean camera_buffer[]) {				
		if(camera_buffer[0]) { // Up
			if(count_up > SENSITIVITY) {
				count_up = 0;
				return true;
				
			}
			count_up++;
		}
		if(camera_buffer[1]) { // Left
			if(count_left > SENSITIVITY) {
				count_left = 0;
				return true;
			}
			count_left++;
		}
		if(camera_buffer[2]) { // Down
			if(count_down > SENSITIVITY) {
				count_down = 0;
				return true;
			}
			count_down++;
		}
		if(camera_buffer[3]) { // Right
			if(count_right > SENSITIVITY) {
				count_right = 0;
				return true;
			}
			count_right++;
		}
		
		return false;
	}
}
