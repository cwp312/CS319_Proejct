package main.rsystem;

/**
 * Part of initial design but later abandoned due to change in design
 * @author Cheol Woo Park
 * @deprecated
 */
public enum PanelType {
	Main, Bestiary, Credits, Options, Instructions, Pause
}
