package main.rsystem;

public enum PanelType {
	Main, Bestiary, Credits, Options, Instructions, Pause
}
